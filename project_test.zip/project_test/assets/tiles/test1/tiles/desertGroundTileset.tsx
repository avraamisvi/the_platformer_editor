<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="desertGroundTileset" tilewidth="64" tileheight="64" tilecount="256" columns="16">
 <image source="../images/tile/ground.png" width="1024" height="1024"/>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="16" width="50" height="48"/>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="16" width="64" height="48"/>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="16" width="50" height="48"/>
  </objectgroup>
 </tile>
 <tile id="20">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="0" width="50" height="64"/>
  </objectgroup>
 </tile>
 <tile id="22">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="50" height="64"/>
  </objectgroup>
 </tile>
 <tile id="36">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="0" width="50" height="40"/>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="64" height="40"/>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="50" height="40"/>
  </objectgroup>
 </tile>
</tileset>
